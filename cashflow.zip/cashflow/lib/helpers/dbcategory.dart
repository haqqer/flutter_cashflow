import 'package:cashflow/helpers/dbhelper.dart';
import 'package:sqflite/sqflite.dart';
import 'dart:async';
import 'package:cashflow/models/cash.dart';

class DbCash extends DbHelper {
  static DbCash _dbHelper;
  static Database _database;

  DbCash._createObject();

  factory DbCash() {
    if(_dbHelper == null) {
      _dbHelper = DbCash._createObject();
    }
    return _dbHelper;
  }
  
  Future<Database> get database async {
    if(_database == null) {
      _database = await initDb();
    }
    return _database;
  }

  Future<List<Map<String, dynamic>>> select() async {
    Database db = await this.database;
    var mapList = await db.query('cash', orderBy: 'name');
    return mapList;
  }

  Future<int> insert(Cash cash) async {
    Database db = await this.database;
    int count = await db.insert('cash', cash.toMap());
    return count;
  }

  Future<int> update(Cash cash) async {
    Database db = await this.database;
    int count = await db.update('cash', cash.toMap(), where: 'id=?', whereArgs: [cash.id]);
    return count;
  }

  Future<int> delete(int id) async {
    Database db = await this.database;
    int count = await db.delete('cash', where: 'id=?', whereArgs: [id]);
    return count;
  }

  Future<List<Cash>> getCashList() async {
    var cashMapList = await select();
    int count = cashMapList.length;
    List<Cash> cashList = List<Cash>();
    for(int i=0; i<count; i++) {
      cashList.add(Cash.fromMap(cashMapList[i]));
    }
    return cashList;
  }
}