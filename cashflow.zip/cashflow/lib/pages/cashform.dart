
import 'package:cashflow/models/cash.dart';
import 'package:flutter/material.dart';

class CashForm extends StatefulWidget {
  final Cash cash;
  CashForm({Key key, this.cash}) : super(key: key);

  @override
  CashFormState createState() => CashFormState(this.cash);
}

class CashFormState extends State<CashForm> {
  Cash cash;
  CashFormState(this.cash);
  final datenow = DateTime.now();
  List _types = ['In', 'Out'];
  List<DropdownMenuItem<String>> _dropDownMenuItems;

  TextEditingController nameController,descriptionController,amountController,totalController = TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    if(cash != null) {
      nameController.text = cash.name;
      descriptionController.text = cash.description;
    }
    return Scaffold(
      appBar: AppBar(
        title: cash == null ? Text('Tambah') : Text('Edit'),
      ),
      body: Padding(
        padding: EdgeInsets.only(top: 15.0, left: 10.0, right: 10.0),
        child: ListView(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 20.0, bottom: 20.0),
              child: TextField(
                controller: nameController,
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  labelText: 'Nama',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5.0)
                  )
                ),
                onChanged: (value) {
                  print(value);
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 20.0, bottom: 20.0),
              child: TextField(
                controller: descriptionController,
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  labelText: 'Telpon',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5.0)
                  )
                ),
                onChanged: (value) {
                  print(value);
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 20.0, bottom: 20.0),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: RaisedButton(
                      color: Colors.white,
                      textColor: Theme.of(context).primaryColor,
                      child: Text(
                        'Save',
                        textScaleFactor: 1.5,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Theme.of(context).primaryColor)
                      ),
                      onPressed: () {
                        // if(cash == null) {
                        //   cash = Cash(nameController.text, descriptionController.text, amountController.text, totalController.text, datenow, datenow);
                        // } else {
                        //   cash.name = nameController.text;
                        //   cash.description = descriptionController.text;
                        // }
                        Navigator.pop(context);
                      },
                    ),
                  ),
                  Container(width: 5.0),
                  Expanded(
                    child: RaisedButton(
                      color: Theme.of(context).primaryColor,
                      textColor: Colors.white,
                      child: Text(
                        'Cancel',
                        textScaleFactor: 1.5,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Theme.of(context).primaryColor)
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
  List<DropdownMenuItem<String>> getDropDownMenuItems() {
    List<DropdownMenuItem<String>> items = List();
    for(String type in _types) {
      items.add(DropdownMenuItem(
        value: type,
        child: Text(type)
      ));
    }
    return items;
  }
}