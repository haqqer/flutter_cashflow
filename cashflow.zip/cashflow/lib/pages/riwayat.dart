import 'package:flutter/material.dart';
import 'package:cashflow/models/cash.dart';
import 'package:cashflow/helpers/dbcash.dart';
import 'package:sqflite/sqflite.dart';

class Riwayat extends StatefulWidget {
  @override
  RiwayatState createState() => RiwayatState();
}

class RiwayatState extends State<Riwayat> {
  DbCash dbCash = DbCash();
  int count = 0;
  Cash cash;
  List<Cash> cashList;  
  @override
  Widget build(BuildContext context) {
    TextStyle textStyle = Theme.of(context).textTheme.subhead;
    return ListView.builder(
      itemCount: count,
      itemBuilder: (BuildContext context, int index) {
        return Card(
          color: Colors.white,
          elevation: 2.0,
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.red,
              child: Icon(Icons.people),
            ),
            title: Text(this.cashList[index].name, style: textStyle),
            subtitle: Text(this.cashList[index].description),
            trailing: GestureDetector(
              child: Icon(Icons.delete),
              onTap: () async {
                deleteCash(this.cashList[index]);
              },
            ),
            onTap: () async {
              print('value');
                // var cash = await navigateToEntryForm(context, this.cashList[index]);
                // if (cash != null) editCash(cash);              
            },
          ),
        );
      },
    );
  }
  void updateListView() {
    final Future<Database> dbFuture = dbCash.initDb();
    dbFuture.then((database) {
      Future<List<Cash>> cashListFuture = dbCash.getCashList();
      cashListFuture.then((cashList) {
        setState(() {
          this.cashList = cashList;
          this.count = cashList.length;
        });
      });
    });
  }  
  void editCash(Cash cash) async {
    int result = await dbCash.update(cash);
    if(result > 0) {
      updateListView();
    }
  }  
  void deleteCash(Cash cash) async {
    int result = await dbCash.delete(cash.id);
    if(result > 0) {
      updateListView();
    }    
  }
}