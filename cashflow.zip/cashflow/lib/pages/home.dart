import 'package:cashflow/helpers/dbhelper.dart';
import 'package:cashflow/pages/cashform.dart';
import 'package:cashflow/pages/riwayat.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:cashflow/models/contact.dart';
import 'package:sqflite/sqflite.dart';

class Home extends StatefulWidget {
  @override
  HomeState createState() => HomeState();
}

class HomeState extends State<Home> {
  DbHelper dbHelper = DbHelper();
  int count = 0;
  Contact contact;
  List<Contact> contactList;
  int _selectedTabIndex;  
  List<Widget> _pages;
  Widget _currentPage;
  @override
  void initState() {
    super.initState();
    _pages = <Widget>[
      MainPage(),
      Text('Kategori'),
      CashForm(),
      Riwayat(),
      Text('Tentang')
    ];      
    _selectedTabIndex = 0;
    _currentPage = MainPage();
  }

  void _onNavbarTapped(int index) {
    setState(() {
      _selectedTabIndex = index;
      _currentPage = _pages[index];
    });
  }  

  @override
  Widget build(BuildContext context) {
    if(contactList == null) {
      contactList = List<Contact>();
    }
    final _listPage = <Widget>[
      MainPage(),
      Text('Kategori'),
      CashForm(),
      Riwayat(),
      Text('Tentang')
    ];    
    final _bottomNavbarItems = <BottomNavigationBarItem>[
      BottomNavigationBarItem(
        icon: Icon(Icons.home),
        title: Text('Beranda')
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.list),
        title: Text('Kategori')
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.add),
        title: Text('Tambah')
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.history),
        title: Text('Riwayat')
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.info),
        title: Text('Tentang')
      )
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Kontak'),
      ),
      body: _currentPage,
      // body: createListView(),
      // floatingActionButton: FloatingActionButton(
      //   child: Icon(Icons.add),
      //   tooltip: 'Tambah Data',
      //   onPressed: () async {
      //     var contact = await navigateToEntryForm(context, null);
      //     if(contact != null) addContact(contact);
      //   },
      // ),
      bottomNavigationBar: BottomNavigationBar(
        items: _bottomNavbarItems,
        currentIndex: _selectedTabIndex,
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.grey,
        onTap: _onNavbarTapped,
      ),
    );
  }

  void navigateToEntryForm(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(
      builder: (BuildContext context) {
        return CashForm();
      }
    ));
  }
  // Future<Contact> navigateToEntryForm(BuildContext context, Contact contact) async {
  //   var result = await Navigator.push(context, MaterialPageRoute(
  //     builder: (BuildContext context) {
  //       return EntryForm(contact);
  //     }
  //   ));
  //   return result;
  // }

  // void addContact(Contact contact) async {
  //   int result = await dbHelper.insert(contact);
  //   if(result > 0) {
  //     updateListView();
  //   }
  // }

  // void editContact(Contact contact) async {
  //   int result = await dbHelper.update(contact);
  //   if(result > 0) {
  //     updateListView();
  //   }
  // }

  // void deleteContact(Contact contact) async {
  //   int result = await dbHelper.delete(contact.id);
  //   if(result > 0) {
  //     updateListView();
  //   }    
  // }

  // void updateListView() {
  //   final Future<Database> dbFuture = dbHelper.initDb();
  //   dbFuture.then((database) {
  //     Future<List<Contact>> contactListFuture = dbHelper.getContactList();
  //     contactListFuture.then((contactList) {
  //       setState(() {
  //         this.contactList = contactList;
  //         this.count = contactList.length;
  //       });
  //     });
  //   });
  // }
}

class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Main page'),
    );
  }
}

